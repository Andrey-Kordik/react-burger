export const ALL_ORDERS_SERVER_URL = "wss://norma.nomoreparties.space/orders/all";

export const MY_ORDERS_SERVER_URL = "wss://norma.nomoreparties.space/orders";

export const BASE_URL = 'https://norma.nomoreparties.space/api';